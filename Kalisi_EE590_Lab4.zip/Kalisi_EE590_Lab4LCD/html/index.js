var index =
[
    [ "Description", "index.html#description", null ],
    [ "Circuit", "index.html#circuit", null ],
    [ "Libraries", "index.html#libraries", null ],
    [ "Notes", "index.html#notes", null ],
    [ "DATE", "index.html#date", null ],
    [ "Author", "index.html#author", null ]
];