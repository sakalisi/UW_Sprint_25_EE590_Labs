var searchData=
[
  ['sendbyte_0',['sendByte',['../_kalisi___e_e590___lab4_l_c_d_8ino.html#a80266826c393af0bf7cd9ccda3b4a734',1,'Kalisi_EE590_Lab4LCD.ino']]],
  ['sendnibble_1',['sendNibble',['../_kalisi___e_e590___lab4_l_c_d_8ino.html#ad642faaae22029bc87d822aa3692f2af',1,'Kalisi_EE590_Lab4LCD.ino']]],
  ['setup_2',['setup',['../_kalisi___e_e590___lab4_l_c_d_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Kalisi_EE590_Lab4LCD.ino']]]
];
