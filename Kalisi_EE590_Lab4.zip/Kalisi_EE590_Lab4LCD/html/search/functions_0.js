var searchData=
[
  ['i2csend_0',['i2cSend',['../_kalisi___e_e590___lab4_l_c_d_8ino.html#a2816de4e7f9d54baaf2df838f5719e23',1,'Kalisi_EE590_Lab4LCD.ino']]]
];
