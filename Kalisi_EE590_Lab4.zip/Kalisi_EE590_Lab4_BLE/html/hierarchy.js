var hierarchy =
[
    [ "BLECharacteristicCallbacks", null, [
      [ "MyCallbacks", "class_my_callbacks.html", null ]
    ] ]
];