var searchData=
[
  ['service_5fuuid_0',['SERVICE_UUID',['../_kalisi___e_e590___lab4___b_l_e_8ino.html#a445125ee8c34695376c85f10b38844d6',1,'Kalisi_EE590_Lab4_BLE.ino']]],
  ['setup_1',['setup',['../_kalisi___e_e590___lab4___b_l_e_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Kalisi_EE590_Lab4_BLE.ino']]]
];
