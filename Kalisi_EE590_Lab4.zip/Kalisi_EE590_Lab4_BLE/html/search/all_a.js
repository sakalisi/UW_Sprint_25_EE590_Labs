var searchData=
[
  ['newmessagereceived_0',['newMessageReceived',['../_kalisi___e_e590___lab4___b_l_e_8ino.html#ac225b5d04ed848deaae5393d2ce5521e',1,'Kalisi_EE590_Lab4_BLE.ino']]],
  ['notes_1',['Notes',['../index.html#notes',1,'']]]
];
