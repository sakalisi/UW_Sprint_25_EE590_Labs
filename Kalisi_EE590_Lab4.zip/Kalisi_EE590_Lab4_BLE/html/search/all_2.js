var searchData=
[
  ['author_0',['Author',['../index.html#author',1,'']]]
];
