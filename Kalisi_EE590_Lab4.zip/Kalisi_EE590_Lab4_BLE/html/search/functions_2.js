var searchData=
[
  ['setup_0',['setup',['../_kalisi___e_e590___lab4___b_l_e_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Kalisi_EE590_Lab4_BLE.ino']]]
];
