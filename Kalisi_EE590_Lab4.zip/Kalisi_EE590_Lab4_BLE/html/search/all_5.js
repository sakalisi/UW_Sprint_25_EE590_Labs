var searchData=
[
  ['date_0',['DATE',['../index.html#date',1,'']]],
  ['description_1',['Description',['../index.html#description',1,'']]]
];
