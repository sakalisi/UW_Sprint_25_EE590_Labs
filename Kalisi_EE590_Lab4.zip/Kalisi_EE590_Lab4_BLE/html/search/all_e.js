var searchData=
[
  ['updatedisplay_0',['updateDisplay',['../_kalisi___e_e590___lab4___b_l_e_8ino.html#a7a700d643e72d0bf85078f58c82b181d',1,'Kalisi_EE590_Lab4_BLE.ino']]]
];
