var searchData=
[
  ['pid_0',['pid',['../struct_t_c_bstruct.html#aec00a68c685612da90f9b9497af066bc',1,'TCBstruct']]],
  ['pin_1',['pin',['../struct_l_e_d_control.html#a12b6d1d9aab9101dcce6e33091ea92f2',1,'LEDControl::pin'],['../struct_l_e_d_freq_control.html#ab81570ddcfd8f18523be0927960b81d2',1,'LEDFreqControl::pin']]],
  ['previousmicros_2',['previousMicros',['../struct_l_e_d_control.html#ae961ef27f35c11eaf1ca69300093a433',1,'LEDControl::previousMicros'],['../struct_l_e_d_freq_control.html#a43ea7697b1ff9c12fe7d1c74b8dc379b',1,'LEDFreqControl::previousMicros'],['../struct_print_control.html#a578e2179e8cb12433821b91300d5979c',1,'PrintControl::previousMicros']]],
  ['previousmillis_3',['previousMillis',['../struct_l_c_d_control.html#a82e0edfc449532f4409344333b9af8cd',1,'LCDControl']]],
  ['printtask_4',['printTask',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a28c8f9767b5436a422e8a812dbbd3dd0',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['priority_5',['priority',['../struct_t_c_bstruct.html#ab168bd831d9b9460a6f0908c93a1d06e',1,'TCBstruct']]]
];
