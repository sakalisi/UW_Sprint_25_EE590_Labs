var searchData=
[
  ['date_0',['DATE',['../index.html#date',1,'']]],
  ['delay_1',['delay',['../struct_t_c_bstruct.html#a4f420dbd4ecc70c34d75be4d16704d12',1,'TCBstruct']]],
  ['description_2',['Description',['../index.html#description',1,'']]]
];
