var searchData=
[
  ['resettasks_0',['resetTasks',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#ac50b730de8a3df0daf18b072e7f35e15',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['resolution_1',['resolution',['../struct_l_e_d_freq_control.html#a6e214099dd2189a57a68386b7e781148',1,'LEDFreqControl']]]
];
