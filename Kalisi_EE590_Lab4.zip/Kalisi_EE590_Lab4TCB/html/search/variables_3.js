var searchData=
[
  ['delay_0',['delay',['../struct_t_c_bstruct.html#a4f420dbd4ecc70c34d75be4d16704d12',1,'TCBstruct']]]
];
