var searchData=
[
  ['taska_0',['taskA',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a35dc93be65481bc48981bfba50174928',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['taskb_1',['taskB',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a31d2fc5c555a4f7e004c3df209f14571',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['taskc_2',['taskC',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a4332a472954ffb41dcca5e45e4cbc7aa',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['taskd_3',['taskD',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#abe00af36829dedee0f4a68d9c5dc1132',1,'Kalisi_EE590_Lab4TCB.ino']]]
];
