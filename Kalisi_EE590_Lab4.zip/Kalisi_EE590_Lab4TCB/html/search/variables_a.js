var searchData=
[
  ['tasklist_0',['TaskList',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a78acf9ab4cce05bf22c87f940768e011',1,'Kalisi_EE590_Lab4TCB.ino']]],
  ['timesincebegintask_1',['timeSinceBeginTask',['../struct_l_e_d_control.html#a789ce55bc308ddd8f300f0780c74d4b8',1,'LEDControl']]],
  ['toprint_2',['toPrint',['../struct_print_control.html#a8db385bbc791ae850bafce9b48d9bb50',1,'PrintControl']]]
];
