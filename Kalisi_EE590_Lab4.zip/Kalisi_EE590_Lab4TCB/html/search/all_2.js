var searchData=
[
  ['arg_5fptr_0',['arg_ptr',['../struct_t_c_bstruct.html#a3f0f40aaaeb47cc916936604723f621c',1,'TCBstruct']]],
  ['author_1',['Author',['../index.html#author',1,'']]]
];
