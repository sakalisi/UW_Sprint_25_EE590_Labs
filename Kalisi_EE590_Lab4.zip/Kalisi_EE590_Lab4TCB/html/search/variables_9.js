var searchData=
[
  ['state_0',['state',['../struct_l_e_d_control.html#a43ee95802d627de1eeb8d480f95c2826',1,'LEDControl::state'],['../struct_t_c_bstruct.html#a78ce2705b4f61c53c67aa89ea894da68',1,'TCBstruct::state']]]
];
