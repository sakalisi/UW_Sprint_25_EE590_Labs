var searchData=
[
  ['resolution_0',['resolution',['../struct_l_e_d_freq_control.html#a6e214099dd2189a57a68386b7e781148',1,'LEDFreqControl']]]
];
