var searchData=
[
  ['changetime_0',['changeTime',['../struct_l_e_d_freq_control.html#a5a1e03c2402906651e9d5597fc1cf322',1,'LEDFreqControl::changeTime'],['../struct_print_control.html#ab767d1652f9ad51616ecd5d3a2110c64',1,'PrintControl::changeTime']]],
  ['circuit_1',['Circuit',['../index.html#circuit',1,'']]],
  ['currentcount_2',['currentCount',['../struct_l_c_d_control.html#aea33c0414261ca0e7af5673df1411bb2',1,'LCDControl::currentCount'],['../struct_print_control.html#af7792cf1d5e0736173462290734e0719',1,'PrintControl::currentCount']]],
  ['currentrunningtask_3',['currentRunningTask',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a88fed21844471f6a824297c7eacf52c0',1,'Kalisi_EE590_Lab4TCB.ino']]]
];
