var searchData=
[
  ['taskstate_0',['taskstate',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#a61b9e2835d487eb729fecbe56ff32d9e',1,'Kalisi_EE590_Lab4TCB.ino']]]
];
