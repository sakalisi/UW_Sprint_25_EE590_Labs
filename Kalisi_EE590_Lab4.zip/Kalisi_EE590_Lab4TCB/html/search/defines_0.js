var searchData=
[
  ['n_5fmax_5ftasks_0',['N_MAX_TASKS',['../_kalisi___e_e590___lab4_t_c_b_8ino.html#aa20dc5438625ad80f27e2b1fc4170c8e',1,'Kalisi_EE590_Lab4TCB.ino']]]
];
