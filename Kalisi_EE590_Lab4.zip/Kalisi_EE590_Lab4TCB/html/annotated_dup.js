var annotated_dup =
[
    [ "LCDControl", "struct_l_c_d_control.html", "struct_l_c_d_control" ],
    [ "LEDControl", "struct_l_e_d_control.html", "struct_l_e_d_control" ],
    [ "LEDFreqControl", "struct_l_e_d_freq_control.html", "struct_l_e_d_freq_control" ],
    [ "PrintControl", "struct_print_control.html", "struct_print_control" ],
    [ "TCBstruct", "struct_t_c_bstruct.html", "struct_t_c_bstruct" ]
];