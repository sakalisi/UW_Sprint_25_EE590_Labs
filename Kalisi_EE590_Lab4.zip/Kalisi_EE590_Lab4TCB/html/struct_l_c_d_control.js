var struct_l_c_d_control =
[
    [ "currentCount", "struct_l_c_d_control.html#aea33c0414261ca0e7af5673df1411bb2", null ],
    [ "interval", "struct_l_c_d_control.html#a30c76c695483e69c63f895cba0c3c257", null ],
    [ "isDone", "struct_l_c_d_control.html#a2934883aeb8e396d9a355132ab123f02", null ],
    [ "previousMillis", "struct_l_c_d_control.html#a82e0edfc449532f4409344333b9af8cd", null ]
];