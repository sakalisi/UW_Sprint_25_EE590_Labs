var struct_t_c_bstruct =
[
    [ "arg_ptr", "struct_t_c_bstruct.html#a3f0f40aaaeb47cc916936604723f621c", null ],
    [ "delay", "struct_t_c_bstruct.html#a4f420dbd4ecc70c34d75be4d16704d12", null ],
    [ "ftpr", "struct_t_c_bstruct.html#ab788829531903e401ce2a34f2dc34938", null ],
    [ "pid", "struct_t_c_bstruct.html#aec00a68c685612da90f9b9497af066bc", null ],
    [ "priority", "struct_t_c_bstruct.html#ab168bd831d9b9460a6f0908c93a1d06e", null ],
    [ "state", "struct_t_c_bstruct.html#a78ce2705b4f61c53c67aa89ea894da68", null ]
];