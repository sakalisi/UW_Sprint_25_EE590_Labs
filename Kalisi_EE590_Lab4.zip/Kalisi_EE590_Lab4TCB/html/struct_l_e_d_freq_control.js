var struct_l_e_d_freq_control =
[
    [ "changeTime", "struct_l_e_d_freq_control.html#a5a1e03c2402906651e9d5597fc1cf322", null ],
    [ "freq", "struct_l_e_d_freq_control.html#a01969e7bc5a045fe3e74da22b63b269f", null ],
    [ "isDone", "struct_l_e_d_freq_control.html#a9a5f15c0f2aba99701c54ba713e2f9f3", null ],
    [ "pin", "struct_l_e_d_freq_control.html#ab81570ddcfd8f18523be0927960b81d2", null ],
    [ "previousMicros", "struct_l_e_d_freq_control.html#a43ea7697b1ff9c12fe7d1c74b8dc379b", null ],
    [ "resolution", "struct_l_e_d_freq_control.html#a6e214099dd2189a57a68386b7e781148", null ],
    [ "variousFreqsChecked", "struct_l_e_d_freq_control.html#a3a2279ece9e0579c601648328affe9b2", null ]
];