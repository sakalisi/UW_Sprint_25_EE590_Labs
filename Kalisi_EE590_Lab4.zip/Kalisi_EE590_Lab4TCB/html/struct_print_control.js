var struct_print_control =
[
    [ "changeTime", "struct_print_control.html#ab767d1652f9ad51616ecd5d3a2110c64", null ],
    [ "currentCount", "struct_print_control.html#af7792cf1d5e0736173462290734e0719", null ],
    [ "isDone", "struct_print_control.html#aaca81b7424e1a1dc3f3b2336e1a8a888", null ],
    [ "previousMicros", "struct_print_control.html#a578e2179e8cb12433821b91300d5979c", null ],
    [ "toPrint", "struct_print_control.html#a8db385bbc791ae850bafce9b48d9bb50", null ]
];