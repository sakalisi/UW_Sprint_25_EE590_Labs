var struct_l_e_d_control =
[
    [ "blinkCount", "struct_l_e_d_control.html#a6d7911f39c9806cf06128a80d8c75371", null ],
    [ "blinkInterval", "struct_l_e_d_control.html#a6ac928847970878a42269763cc82d8ef", null ],
    [ "isBlinking", "struct_l_e_d_control.html#a595e9060aaddc4254faf1ff9010f0951", null ],
    [ "isDone", "struct_l_e_d_control.html#ac0d13f84549075afdfa02351ed3f1e2d", null ],
    [ "pin", "struct_l_e_d_control.html#a12b6d1d9aab9101dcce6e33091ea92f2", null ],
    [ "previousMicros", "struct_l_e_d_control.html#ae961ef27f35c11eaf1ca69300093a433", null ],
    [ "state", "struct_l_e_d_control.html#a43ee95802d627de1eeb8d480f95c2826", null ],
    [ "timeSinceBeginTask", "struct_l_e_d_control.html#a789ce55bc308ddd8f300f0780c74d4b8", null ]
];