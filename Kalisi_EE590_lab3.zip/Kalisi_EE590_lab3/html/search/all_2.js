var searchData=
[
  ['add_5f1_0',['add_1',['../_kalisi___e_e590__lab3_8ino.html#a736536269ee779cf2ee64060fc5ce92f',1,'Kalisi_EE590_lab3.ino']]],
  ['addelement_1',['addElement',['../590_lab3_8cpp.html#a68406c3105b30484589792cf7ede6b52',1,'addElement(DynamicArray *arr, int element):&#160;590Lab3.cpp'],['../590_lab3_8h.html#a68406c3105b30484589792cf7ede6b52',1,'addElement(DynamicArray *arr, int element):&#160;590Lab3.cpp']]],
  ['array_5fmodify_2',['array_modify',['../590_lab3_8cpp.html#ae6ddee90069a7c44cef2d9084f81bfde',1,'array_modify(int *arr, size_t len, int(*mod_func)(int)):&#160;590Lab3.cpp'],['../590_lab3_8h.html#ae6ddee90069a7c44cef2d9084f81bfde',1,'array_modify(int *arr, size_t len, int(*mod_func)(int)):&#160;590Lab3.cpp']]],
  ['author_3',['Author',['../index.html#author',1,'']]]
];
