var searchData=
[
  ['buffer_5fsize_0',['BUFFER_SIZE',['../590_lab3_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE:&#160;590Lab3.h'],['../_special590functions_8cpp.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE:&#160;Special590functions.cpp']]]
];
