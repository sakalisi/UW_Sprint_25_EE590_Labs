var searchData=
[
  ['time_5fdiv_0',['TIME_DIV',['../_kalisi___e_e590__lab3_8ino.html#a9253f3e2148bef241e53597e917d3016',1,'Kalisi_EE590_lab3.ino']]],
  ['time_5fen_1',['TIME_EN',['../_kalisi___e_e590__lab3_8ino.html#accb619222552bdc4fc8590cb57068b2e',1,'Kalisi_EE590_lab3.ino']]],
  ['time_5fincrement_5fmode_2',['TIME_INCREMENT_MODE',['../_kalisi___e_e590__lab3_8ino.html#a2868e403a58438f7bc768902620f0b3b',1,'Kalisi_EE590_lab3.ino']]]
];
