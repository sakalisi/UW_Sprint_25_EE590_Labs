var searchData=
[
  ['initial_5fbuffer_5fsize_0',['INITIAL_BUFFER_SIZE',['../_kalisi___e_e590__lab3_8ino.html#a1d51567e0f6916e91f5bd3719d56cce6',1,'Kalisi_EE590_lab3.ino']]]
];
