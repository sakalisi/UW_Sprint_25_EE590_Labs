var searchData=
[
  ['data_0',['data',['../struct_dynamic_array.html#ac103627c1ad15cbec2f22d0abe6d54b6',1,'DynamicArray']]]
];
