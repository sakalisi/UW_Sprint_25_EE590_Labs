var searchData=
[
  ['3_0',['Base functions for Lab 3',['../index.html',1,'']]]
];
