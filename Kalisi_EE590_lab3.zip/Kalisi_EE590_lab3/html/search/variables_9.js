var searchData=
[
  ['tail_0',['tail',['../struct_circular_buffer.html#ad71c3da585299fa719501f5149814fd7',1,'CircularBuffer']]],
  ['task_5fid_1',['task_id',['../struct_task.html#a24913131dc491a81c23f2b8246d85e3b',1,'Task']]]
];
