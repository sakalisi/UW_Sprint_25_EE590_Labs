var searchData=
[
  ['size_0',['size',['../struct_dynamic_array.html#a439227feff9d7f55384e8780cfc2eb82',1,'DynamicArray']]],
  ['state_1',['state',['../struct_task.html#aebc38c74e1bb052cdefe524ef4806f2b',1,'Task']]],
  ['stringbuffer_2',['stringBuffer',['../_special590functions_8cpp.html#a1964074eb6691c0bb046715210e45329',1,'Special590functions.cpp']]]
];
