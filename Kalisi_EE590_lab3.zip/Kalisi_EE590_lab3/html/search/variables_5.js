var searchData=
[
  ['max_5fsize_0',['max_size',['../struct_circular_buffer.html#af4728438dee601cb2554d9bf18d78a43',1,'CircularBuffer']]]
];
