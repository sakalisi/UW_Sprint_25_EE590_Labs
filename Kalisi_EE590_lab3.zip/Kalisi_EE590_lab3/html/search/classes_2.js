var searchData=
[
  ['task_0',['Task',['../struct_task.html',1,'']]]
];
