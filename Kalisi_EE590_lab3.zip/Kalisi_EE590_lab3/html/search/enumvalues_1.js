var searchData=
[
  ['ready_0',['READY',['../590_lab3_8h.html#a724f9ce2351c125b3b7f6c7923822bcea6564f2f3e15be06b670547bbcaaf0798',1,'590Lab3.h']]],
  ['running_1',['RUNNING',['../590_lab3_8h.html#a724f9ce2351c125b3b7f6c7923822bcea1061be6c3fb88d32829cba6f6b2be304',1,'590Lab3.h']]]
];
