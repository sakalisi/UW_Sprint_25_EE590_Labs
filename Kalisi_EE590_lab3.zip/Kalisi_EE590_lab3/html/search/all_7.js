var searchData=
[
  ['head_0',['head',['../struct_circular_buffer.html#a75844ce74940ef333d11ae090e07c9af',1,'CircularBuffer']]]
];
