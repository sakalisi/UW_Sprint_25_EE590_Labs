var searchData=
[
  ['background_5ftimer_0',['BACKGROUND_timer',['../_kalisi___e_e590__lab3_8ino.html#a26ae286c8f1470d907f0f5fa97d82154',1,'Kalisi_EE590_lab3.ino']]],
  ['buffer_1',['buffer',['../struct_circular_buffer.html#a74c07922a00b8d07d761cfc6e03ae354',1,'CircularBuffer']]]
];
