var files_dup =
[
    [ "590Lab3.cpp", "590_lab3_8cpp.html", "590_lab3_8cpp" ],
    [ "590Lab3.h", "590_lab3_8h.html", "590_lab3_8h" ],
    [ "Kalisi_EE590_lab3.ino", "_kalisi___e_e590__lab3_8ino.html", "_kalisi___e_e590__lab3_8ino" ],
    [ "Special590functions.cpp", "_special590functions_8cpp.html", "_special590functions_8cpp" ],
    [ "Special590functions.h", "_special590functions_8h.html", "_special590functions_8h" ]
];