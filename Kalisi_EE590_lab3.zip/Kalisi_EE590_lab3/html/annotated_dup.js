var annotated_dup =
[
    [ "CircularBuffer", "struct_circular_buffer.html", "struct_circular_buffer" ],
    [ "DynamicArray", "struct_dynamic_array.html", "struct_dynamic_array" ],
    [ "Task", "struct_task.html", "struct_task" ]
];