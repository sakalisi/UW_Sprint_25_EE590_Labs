var struct_dynamic_array =
[
    [ "capacity", "struct_dynamic_array.html#adbe66a087ac3fd4a5b0566f64ca2d12b", null ],
    [ "data", "struct_dynamic_array.html#ac103627c1ad15cbec2f22d0abe6d54b6", null ],
    [ "size", "struct_dynamic_array.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];