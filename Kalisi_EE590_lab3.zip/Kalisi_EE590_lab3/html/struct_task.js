var struct_task =
[
    [ "run_time", "struct_task.html#a395a9f70b6cde977a1be3d62895c605b", null ],
    [ "state", "struct_task.html#aebc38c74e1bb052cdefe524ef4806f2b", null ],
    [ "task_id", "struct_task.html#a24913131dc491a81c23f2b8246d85e3b", null ]
];