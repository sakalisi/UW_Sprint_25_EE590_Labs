var struct_circular_buffer =
[
    [ "buffer", "struct_circular_buffer.html#a74c07922a00b8d07d761cfc6e03ae354", null ],
    [ "count", "struct_circular_buffer.html#a76d971a3c552bc58ba9f0d5fceae9806", null ],
    [ "head", "struct_circular_buffer.html#a75844ce74940ef333d11ae090e07c9af", null ],
    [ "max_size", "struct_circular_buffer.html#af4728438dee601cb2554d9bf18d78a43", null ],
    [ "tail", "struct_circular_buffer.html#ad71c3da585299fa719501f5149814fd7", null ]
];