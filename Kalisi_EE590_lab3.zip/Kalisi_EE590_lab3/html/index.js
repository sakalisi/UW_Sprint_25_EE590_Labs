var index =
[
    [ "Description", "index.html#description", null ],
    [ "Notes", "index.html#notes", null ],
    [ "DATE", "index.html#date", null ],
    [ "Author", "index.html#author", null ]
];